/*
Lab1
Paras Kumar
2016CSB1047
Decision Tree Learning Algorithms
*/


#include<iostream>
#include<cstdlib>
#include<fstream>
#include<string>
#include<sstream>
#include<string.h>
#include<map>
#include<vector>
#include<set>
#include<math.h>
#include<ctime>

using namespace std;

struct Node{
	int attr;
	set<int> examples;
	struct Node *yes, *no;
	Node(int data){
		this->attr = data;
		yes = no = NULL;
	}
};

char test_path[] = "dataset/test/labeledBow.feat";
char train_path[] = "dataset/labeledBow.feat";
char vocabulary_path[] = "dataset/imdbEr.txt";

//Default max depth of leaf node
int max_depth = 100;
//Matrix to store test and training data for simple decision tree
int M[1000][5001];
//word map for simple decision tree
map<int, int> word_map;

//Default number of trees in random forest
int no_trees = 3;
//Array of matrices to store test data for random forest
vector< vector< vector<int> > > M_array;
//word map for random forest
vector< map<int, int> > word_map_array;
//Root nodes for Random forest
vector<Node*> Root;

//index of words
set <int> voc;

//Used for experiment
int no_terminal_nodes = 0;
int total_no_nodes = 0;
int no_nodes_pruning = 0;
map<int, int> attr_count_map;


//Simple inorder tarversal
void inorder(struct Node* root){
	if(root==NULL){
		return;
	}
	inorder(root->yes);
	cout<<root->attr<<" ";
	inorder(root->no);
}

//Counting internal nodes
void inorder_count(struct Node* root){
	if(root==NULL || root->attr==-2 || root->attr==-3){
		return;
	}
	inorder_count(root->yes);
	no_nodes_pruning++;
	inorder_count(root->no);
}

//Allocate memory for vectors depending number of trees
void create_M_array(){
    word_map_array.resize(no_trees);
    M_array.resize(no_trees);
    Root.resize(no_trees);
    for(int k=0; k<no_trees; k++){
        M_array[k].resize(1000);
        for(int i=0; i<1000; i++){
            M_array[k][i].resize(5001);
        }
    }
}

//Copying inorder sequence of nodes to a vector
void inorder_copy(struct Node* root){
	if(root==NULL || root->attr==-2 || root->attr==-3){
		return;
	}
	inorder_copy(root->yes);
	if(root->examples.size()>0 && root->examples.size() < 1000){
		Root.push_back(root);
	}
	inorder_copy(root->no);
}

//Make all elements  of matrix 0
void clear_matrix(int index){
    for(int i=0; i<1000; i++){
        for(int j=0; j<5001; j++){
            if(index == -1){
                M[i][j] = 0;
            }
            else{
                M_array[index][i][j] = 0;
            }
        }
    }
}

//Load training or test data
void load_training_data(char* path, bool is_random_forst, int index){
	ifstream infile(path);
	map <int, vector<int> > M_tmp;
	string line;
	int line_no = 0;
	while( getline(infile, line) ){
		char tmp[line.length()+1];
		strcpy(tmp, line.c_str());
		char* sub_str = strtok(tmp, " ");
		char* attr = sub_str;
		vector <int> v;
		int i = 0;
		while(sub_str!=NULL){
			i++;
			int count;
			if(i%2==1){
				count = atoi(sub_str);
			}
			else{
				v.push_back(atoi(sub_str));
//				cout<<atoi(sub_str)<<endl;
			}
			sub_str = strtok(NULL, " :");

		}
		v.push_back(atoi(attr));
		M_tmp[line_no] = v;
	line_no++;
//break;
	}
	int pos = 0;
	while(pos<500){
		int key = rand()%24999;
		if(M_tmp[key][M_tmp[key].size()-1]>=7){
			for(int i=0; i<M_tmp[key].size()-1; i++){
                if(is_random_forst){
                    M_array[index][pos][word_map_array[index][M_tmp[key][i]]] = 1;
                }
                else{
                    M[pos][word_map[M_tmp[key][i]]] = 1;
                }
			}
            if(!is_random_forst){
                M[pos][5000] = M_tmp[key][M_tmp[key].size()-1];
            }
            else{
                M_array[index][pos][5000] = M_tmp[key][M_tmp[key].size()-1];
            }
			pos++;
		}
	}
	int neg = 0;
	while(neg<500){
		int key = rand()%24999;
		if(M_tmp[key][M_tmp[key].size()-1]<=4){
			for(int i=0; i<M_tmp[key].size()-1; i++){
                if(is_random_forst){
                    M_array[index][neg+500][word_map_array[index][M_tmp[key][i]]] = 1;
                }
                else{
                    M[neg+500][word_map[M_tmp[key][i]]] = 1;
                }
			}
            if(!is_random_forst){
                M[neg+500][5000] = M_tmp[key][M_tmp[key].size()-1];
            }
            else{
                M_array[index][neg+500][5000] = M_tmp[key][M_tmp[key].size()-1];
            }
			neg++;
		}
	}
}

//Get top good and bad words
set<int> get_top_attr(int n, bool use_random_subset, int index){
	ifstream infile(vocabulary_path);
	int word_index = 0;
	map <float, int> M;
	int line_no = 0;
	float tmp;
	while(infile>>tmp){
		M[tmp] = line_no;
		line_no++;
		attr_count_map[line_no] = 0;
	}
	set<int> S;
	map <float, int> :: iterator it;
	int i =0;
	for (it = M.begin(); it!=M.end(); it++){
        if(!use_random_subset){
            S.insert((*it).second);
            word_map[(*it).second] = word_index++;
        }
        else if(rand()%2 == 0){
            S.insert((*it).second);
            word_map_array[index][(*it).second] = word_index++;
        }
        i++;
        if(i>=n){
            break;
        }
	}
    int pos = S.size();
	i =0;
	for (it = M.end(); it!=M.begin(); ){
		--it;
        if(!use_random_subset){
            S.insert((*it).second);
            word_map[(*it).second] = word_index++;
        }
        else if(rand()%2 == 0){
            S.insert((*it).second);
            word_map_array[index][(*it).second] = word_index++;
        }
        i++;
        if(S.size() == pos*2){
            break;
        }
	}
	int neg = S.size()-pos;
//	cout<<"pos="<<pos<<" neg="<<neg<<endl;
	return S;
}

double entropy(int p, int n){
    return (-1*(double)p/(p+n)*log((double)p/(p+n)))/log(2) +
                 (-1*(double)n/(p+n)*log((double)n/(p+n)))/log(2);
}

double info_gain(int P, int N ,int p1, int n1 ,int p2, int n2){
    return entropy(P,N) - (entropy(p1,n1)*(p1+n1)/(P+N)) - (entropy(p2,n2)*(p2+n2)/(P+N));
}

//Counting positive and negative examples from training data to build decision tree
vector<int>* find_exp_pos(set<int> s, int word_index, bool use_random_subset, int index){
    static vector<int> count[4];
    for(int i=0; i<4; i++){
        count[i].erase(count[i].begin(), count[i].end());
    }
    set<int> :: iterator it;
    if(!use_random_subset){
        for(it = s.begin(); it!=s.end(); it++){
            if(M[(*it)][word_map[word_index]] == 1){
                if(M[(*it)][5000]>5){
                    count[0].push_back(*it);
                }
                else{
                    count[1].push_back(*it);
                }
            }
            else{
                if(M[(*it)][5000]>5){
                    count[2].push_back(*it);
                }
                else{
                    count[3].push_back(*it);
                }
            }
        }
    }
    else{
        for(it = s.begin(); it!=s.end(); it++){
            if(M_array[index][(*it)][word_map_array[index][word_index]] == 1){
                if(M_array[index][(*it)][5000]>5){
                    count[0].push_back(*it);
                }
                else{
                    count[1].push_back(*it);
                }
            }
            else{
                if(M_array[index][(*it)][5000]>5){
                    count[2].push_back(*it);
                }
                else{
                    count[3].push_back(*it);
                }
            }
        }
    }
    return count;
}

int count_positive_reviews(set<int> s, bool use_random_subset, int index){
    int count = 0;
    set<int> :: iterator it;
    if(!use_random_subset){
        for(it = s.begin(); it!=s.end(); it++){
            if(M[*it][5000]>5){
                count++;
            }
        }
    }
    else{
        for(it = s.begin(); it!=s.end(); it++){
            if(M_array[index][*it][5000]>5){
                count++;
            }
        }
    }
    return count;
}

set<int> create_subset_training_data(vector<int> a, vector<int> b){
    set<int> subset;
    int i=0;
    for( ; i<a.size(); i++){
        subset.insert(a[i]);
    }
    for(int j =0; j<b.size(); j++){
        subset.insert(b[j]);
    }
    return subset;
}

void build_decision_tree(struct Node* root, set<int> examples, int level, set<int> top_attr, bool use_random_subset, int index){
    total_no_nodes++;
    set<int> sub1;
    set<int> sub2;
    int no_exp = examples.size();
    int no_exp_pos = count_positive_reviews(examples, use_random_subset, index);
    root->examples = examples;
    if(no_exp_pos == no_exp){
        root->attr = -2;
        no_terminal_nodes++;
        return;
    }
    if(no_exp_pos == 0){
        root->attr = -3;
        no_terminal_nodes++;
        return;
    }
    double info_gain_v = -1;
    int selected_attr = -1;

	set <int> :: iterator it;
	for (it = voc.begin(); it!=voc.end(); it++){
//         cout<<"attr="<<*it<<endl;
         vector<int>* tmp = find_exp_pos(examples, (*it), use_random_subset, index);
		 int info_gain_tmp = info_gain(no_exp_pos, no_exp-no_exp_pos,tmp[0].size(),tmp[1].size(),tmp[2].size(),tmp[3].size());
//		 cout<<tmp[0].size()<<" "<<tmp[1].size()<<" "<<tmp[2].size()<<" "<<tmp[3].size()<<endl;
		 if(info_gain_tmp - info_gain_v > 0){
//		 cout<<tmp[0].size()<<" "<<tmp[1].size()<<" "<<tmp[2].size()<<" "<<tmp[3].size()<<endl;
            info_gain_v = info_gain_tmp;
            selected_attr = (*it);
            sub1 = create_subset_training_data(tmp[0], tmp[1]);
            sub2 = create_subset_training_data(tmp[2], tmp[3]);
		 }
//		 cout<<"|";
	}
	cout<<"|";
	if(info_gain_v == -1 || level >= max_depth){
        if(no_exp_pos > no_exp/2){
            root->attr = -2;
            no_terminal_nodes++;
        }
        else{
            root->attr = -3;
            no_terminal_nodes++;
        }
//        cout<<no_exp_pos<<" "<<no_exp-no_exp_pos<<endl;
//        cout<<"No better attr"<<endl;
        return;
	}
//	cout<<"selected="<<selected_attr<<endl;
	root->attr = selected_attr;
	top_attr.erase(selected_attr);
	attr_count_map[selected_attr] = attr_count_map[selected_attr] + 1;
	struct Node* yes_node = new Node(-1);
	struct Node* no_node = new Node(-1);
	root->yes = yes_node;
	root->no = no_node;
//cout<<sub1.size()<<" "<<sub2.size()<<endl;

    build_decision_tree(yes_node, sub1, level+1, top_attr, use_random_subset, index);
    build_decision_tree(no_node, sub2, level+1, top_attr, use_random_subset, index);
}

//Test simple decision tree
float test(Node* root){
    int count = 0;
    for(int i=0; i<1000; i++){
        Node* previous;
        Node* current = root;
        while(current && current->attr != -2 && current->attr != -3){
            previous = current;
            if(M[i][word_map[current->attr]] == 1){
                current = current->yes;
            }
            else{
                current = current->no;
            }
        }
        if(current!= NULL){
            if(M[i][5000] > 5 && current->attr == -2){
                count++;
            }
            if(M[i][5000] < 5 && current->attr == -3){
                count++;
            }
        }
        else if(M[i][5000] > 5 && previous->attr == -2){
            count++;
        }
        if(M[i][5000] < 5 && previous->attr == -3){
            count++;
        }
    }
//    cout<<"Accuracy= "<<(float)count/10<<"%"<<endl;
    return (float)count/10;
}

set<int> create_full_set(int n){
    set<int> s;
    for(int i=0; i<n; i++){
        s.insert(i);
    }
    return s;
}

//Test random forest
float test_forest(){
    int count = 0;
    for(int i=0; i<1000; i++){
        int local_count = 0;
        for(int j=0; j<no_trees; j++){
            Node* previous;
            Node* current = Root[j];
            while(current){
                previous = current;
                if(M[i][word_map[current->attr]] == 1){
                    current = current->yes;
                }
                else{
                    current = current->no;
                }
            }
            if(M[i][5000] > 5 && previous->attr == -2){
                local_count++;
            }
            if(M[i][5000] < 5 && previous->attr == -3){
                local_count++;
            }
        }
        if(local_count > no_trees/2){
            count++;
        }
    }
    clear_matrix(-1);
    return (float)count/10;
}

//Create a simple decision tree
Node* simple_decision_tree(float percentage){
    no_terminal_nodes = 0;
    total_no_nodes = 0;
	voc = get_top_attr(2500, false, -1);
	cout<<"Top 5000 attributes loaded"<<endl;
    clear_matrix(-1);
	load_training_data(train_path, false, -1);
	cout<<"Training data loaded"<<endl;
    for(int i=0; i<1000; i++){
        float rand_no = (float)(rand()%100);
        if(rand_no<=percentage+1 && rand_no>=1){
            if(M[i][5000]<5){
                M[i][5000] = 9;
            }
            else{
                M[i][5000] = 1;
            }
        }
    }
	struct Node* root = new Node(-1);
	cout<<"Learning..."<<endl;
    build_decision_tree(root, create_full_set(1000), 0, voc, false, -1);
    cout<<endl;
    max_depth = 100;
    return root;
}

//Create a random forest
void random_forest(){
    create_M_array();
    for(int i=0; i<no_trees; i++){
        cout<<"Constructing tree no "<<i+1<<endl;
        Root[i] = new Node(-1);
        voc.clear();
        voc = get_top_attr(2500, true, i);
        cout<<voc.size()<<" out of Top 5000 attributes loaded"<<endl;
        load_training_data(train_path, true, i);
        cout<<"Training data loaded"<<endl;

        cout<<"Learning..."<<endl;
        build_decision_tree(Root[i], create_full_set(1000), 0, voc, true, i);
        cout<<endl;
//        inorder(root[i]);
//        cout<<endl;
        clear_matrix(i);
    }
}

//Create pruned simple decision tree
Node* prunned_decision_tree(Node* root, float accuracy){
    Root.clear();
    inorder_copy(root);
    float max_accuracy = 0;
    int selected_index = -1;
    for(int i=0; i<Root.size(); i++){

        if(Root[i] !=NULL && Root[i]->attr != -2 && Root[i]->attr != -3){
            int local_attr = Root[i]->attr;
            int n = Root[i]->examples.size();
            int pos = count_positive_reviews(Root[i]->examples, false, -1);
            if(pos >= n/2){
                Root[i]->attr = -2;
            }
            else{
                Root[i]->attr = -3;
            }
            float tmp =test(root);
            if( tmp> accuracy && tmp>max_accuracy){
                selected_index = i;
                max_accuracy = tmp;
            }
            Root[i]->attr = local_attr;
        }
    }
    if(max_accuracy > accuracy){
        int n = Root[selected_index]->examples.size();
        int pos = count_positive_reviews(Root[selected_index]->examples, false, -1);
        if(pos >= n/2){
            Root[selected_index]->attr = -2;
        }
        else{
            Root[selected_index]->attr = -3;
        }
        inorder_count(root);
        cout<<no_nodes_pruning<<"             "<<max_accuracy<<endl;
        prunned_decision_tree(root, max_accuracy);
    }
    no_nodes_pruning = 0;
    return root;
}

void experiment1(){
    clear_matrix(-1);
    cout<<"EXPERIMENT 1"<<endl<<endl;
    vector<int> max_depth_array;
    vector<int> no_terminal_nodes_array;
    vector<float> accuracy_array_train;
    vector<float> accuracy_array_test;
    vector< map<int, int> > attr_count_array_of_map;
    for(int i=5; i<50; i+=10){
        max_depth = i;
        Node* root = simple_decision_tree(0);
        accuracy_array_train.push_back(test(root));
        load_training_data(test_path, false, -1);
        cout<<"Test data loaded"<<endl;
        accuracy_array_test.push_back(test(root));
        max_depth_array.push_back(i);
        no_terminal_nodes_array.push_back(no_terminal_nodes);
        map<int, int>::iterator it;
        map<int, int> tmp;
        for(it=attr_count_map.begin(); it!=attr_count_map.end(); it++){
            if((*it).second > 2){
                tmp[(*it).first] = (*it).second;
            }
        }
        attr_count_array_of_map.push_back(tmp);
    }

    cout<<endl<<"Effect of early stopping on number of terminal nodes"<<endl;
          cout<<"----------------------------------------------------"<<endl;
    cout<<"Max depth   number of terminal nodes "<<endl;
    for(int i=0; i<max_depth_array.size(); i++){
        cout<<max_depth_array[i]<<"                  "<<no_terminal_nodes_array[i]<<endl;
    }

    cout<<endl<<"Effect of early stopping on train and test accuracy"<<endl;
          cout<<"---------------------------------------------------"<<endl;
    cout<<"Max depth    Training Accuracy   Test Accuracy"<<endl;
    for(int i=0; i<max_depth_array.size(); i++){
        cout<<max_depth_array[i]<<"                  "<<accuracy_array_train[i]<<"                  "<<accuracy_array_test[i]<<endl;
    }

    cout<<endl<<"Effect of early stopping on most frequently used attributes"<<endl;
          cout<<"-----------------------------------------------------------"<<endl;
    for(int i=0; i<max_depth_array.size(); i++){
        cout<<"Max Depth "<<max_depth_array[i]<<endl;
        map<int, int>::iterator it;
        cout<<"Attribute index  Number of times used"<<endl;
        for(it=attr_count_array_of_map[i].begin(); it!=attr_count_array_of_map[i].end(); it++){
            cout<<(*it).first<<"                  "<<(*it).second<<endl;
        }
    }

}

void experiment2(){
    clear_matrix(-1);
    cout<<"EXPERIMENT 2"<<endl<<endl;
    vector<int> no_nodes_array;
    vector<float> test_accuracy_array;
    float error_values[] = {0, .5, 1, 5, 10};
    for(int i=0; i<5; i++){
        Node* root = simple_decision_tree(error_values[i]);
        load_training_data(test_path, false, -1);
        cout<<"Test data loaded"<<endl;
        test_accuracy_array.push_back(test(root));
        no_nodes_array.push_back(total_no_nodes);
        clear_matrix(-1);
    }
    cout<<"Effect of noise on decision tree"<<endl;
    cout<<"--------------------------------"<<endl;
    cout<<"%Noise    No of nodes    Accuracy on test data"<<endl;
    for(int i=0; i<5; i++){
         cout<<error_values[i]<<"             "<<no_nodes_array[i]<<"              "<<test_accuracy_array[i]<<endl;
    }
}

void experiment3(){
    clear_matrix(-1);
    max_depth = 100;
    cout<<"EXPERIMENT 3"<<endl<<endl;
    Node* root = simple_decision_tree(0);
    load_training_data(test_path, false, -1);
    cout<<"Test data loaded"<<endl;
    cout<<"Effect of pruning on accuracy decision tree"<<endl;
    cout<<"-------------------------------------------"<<endl;
    cout<<"No of nodes  Accuracy"<<endl;
    cout<<total_no_nodes<<"             "<<test(root)<<endl;
    prunned_decision_tree(root, test(root));
}

void experiment4(){
    clear_matrix(-1);
    int tree_array[] = {3, 5, 7, 9};
    vector<float> accuracy_test;
    vector<float> accuracy_train;
    cout<<"EXPERIMENT 4"<<endl<<endl;
    for(int i=0; i<4; i++){
        no_trees = tree_array[i];
        create_M_array();
        cout<<"Constructing forest with "<<no_trees<<" trees"<<endl;
        random_forest();

        clear_matrix(-1);
        voc.clear();
        voc = get_top_attr(2500, false, -1);
        load_training_data(train_path, false, -1);
        cout<<"Training data loaded\n"<<endl;

        accuracy_train.push_back(test_forest());

        clear_matrix(-1);
        voc.clear();
        voc = get_top_attr(2500, false, -1);
        load_training_data(test_path, false, -1);
        cout<<"Test data loaded\n"<<endl;

        accuracy_test.push_back(test_forest());

        cout<<"Accuracy of forest "<<i+1<<" Test = "<<accuracy_test[i]<<"% Train = "<<accuracy_train[i]<<"%"<<endl;
        M_array.clear();
        word_map_array.clear();
    }
    cout<<"Effect of number of trees in accuracy of random forest"<<endl;
    cout<<"------------------------------------------------------"<<endl;
    cout<<"No of trees     Test Accuracy       Train Accuracy"<<endl;
    for(int i=0; i<4; i++){
        cout<<tree_array[i]<<"                "<<accuracy_test[i]<<"                "<<accuracy_train[i]<<endl;
    }
}

int main(){
    int choice = 0;

    cout<<"Enter experiment number to run(1-4): ";
    cin>>choice;
    if(choice == 1){
        experiment1();
    }
    else if(choice == 2){
        experiment2();
    }
    else if(choice == 3){
        experiment3();
    }
    else if(choice == 4){
        experiment4();
    }
    return 0;
}
